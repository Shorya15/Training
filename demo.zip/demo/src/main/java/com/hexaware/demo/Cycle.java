package com.hexaware.demo;

public class Cycle implements IVehicle {

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("Cycle is moving");
	}

}
