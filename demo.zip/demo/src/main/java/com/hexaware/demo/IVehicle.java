package com.hexaware.demo;

public interface IVehicle {
	
	public void move();

}
