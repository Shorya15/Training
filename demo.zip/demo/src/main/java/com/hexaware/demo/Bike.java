package com.hexaware.demo;

public class Bike implements IVehicle {

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("Bike is moving");

	}

}
