package com.hexaware.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mySQL")// to make the bean of the class -- annotation based
@Primary // to give this class a priority when multiple bean are created
public class MySqlDataSource implements IDataSource {

	@Override
	public void returnConnection() {
		// TODO Auto-generated method stub

		System.out.println("MySQL database is called ..");
	}

}